extends Node


const LOG_NAME := "memasevich-RussianLocalization"
const TRANSLATION_PATH := "res://mods-unpacked/memasevich-RussianLocalization/translations/ru.json"


func _init() -> void:
	_install_translation()


func _install_translation() -> void:
	if not FileAccess.file_exists(TRANSLATION_PATH):
		ModLoaderLog.error("Translation file is missing: %s" % TRANSLATION_PATH, LOG_NAME)
		return

	var file := FileAccess.open(TRANSLATION_PATH, FileAccess.READ)
	if file == null:
		ModLoaderLog.error("Unable to open translation file: %s" % TRANSLATION_PATH, LOG_NAME)
		return

	var parsed = JSON.parse_string(file.get_as_text())
	if typeof(parsed) != TYPE_DICTIONARY:
		ModLoaderLog.error("Translation file is not a JSON dictionary", LOG_NAME)
		return

	var translation := Translation.new()
	translation.locale = "ru"
	var count := 0
	for key in parsed.keys():
		translation.add_message(str(key), str(parsed[key]))
		count += 1

	TranslationServer.add_translation(translation)
	ModLoaderLog.success("Russian dictionary loaded: %d keys" % count, LOG_NAME)
